Problem 1 (index.html, about_me.html, style.css about_me.css, pic.jpg)

    To make the website, I first used the index.html as my home page. It is made
    up of 3 containers using 3 <div> tags: the navigation bar, the main text, 
    and the contact bar at the bottom of the page. The background of this page 
    was made by styling the <body> tag in the css file style.css. In this file, 
    I also styled the type, color, and size of the fonts on the home page as 
    well as the shape, color, and size of the navigation and contact bars. I 
    used <a> tag to create links for the navigation and contact bar so my 
    Linkedin, email, and about me page are accesbible from the home page.
    I used a separate html and css files labeled about_me to for the About me 
    page. The about me page contains several links in the html file and the
    fonts and containers were styled in the css file. 
    
Problem 2 (Hours.java)
    
    For this problem, I first wrote code to retrieve the needed inputs from the
    user wwhich is the number of years, weeks, and days that they are converting
    into hours. This was accomplished using a Scanner method. Once I had the 
    input values from the users stored as the variables years, weeks, and days, I 
    needed to perform calculations on these values to turn it into hours. I 
    converted each input into hours seperately and added all the values up 
    and stored it in the variable TotalHours. I then printed the final result in 
    a sentence. 

Problem 3 (Easter.java)
    
    For this problem, I used a Scanner method to get input from the user on 
    which year they wanted to check the Easter date for. I then stored this 
    value in variable y and performed the necessary calculations and stored 
    values based on Gauss' formula. I then printed the result as a sentence.
    
Problem 4 (Year.java)
    
    For this problem, I declared the Year as the instance variable because it
    the one value needed of any object to test if it is a leap year. For the 
    constructor, I used the method Year to set the year_input variable which
    stores the value of the year that the user inputs into the integer y. The 
    value of the Year variable is now set to integer y. Using the Year variable
    and a boolean, I can test the dIisibility rules on the Year to see if it a
    leap year. 
    

    
    
      
