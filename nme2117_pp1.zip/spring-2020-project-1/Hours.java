/**
 * This program converts a number of days, weeks, and years into hours.
 * 
 * @author: Nnedi Eze
 * nme2117
 * @date: 2/10/2020
 */

import java.util.Scanner;

public class Hours{
    
    public static void main(String[] args){
        
        //Gets info from user
        Scanner input;
        input = new Scanner(System.in);
        
        System.out.println("Please enter a number of years: ");
        int years = input.nextInt();
        
        System.out.println("Please enter a number of weeks: ");
        int weeks = input.nextInt();
        
        System.out.println("Please enter a number of days: ");
        int days = input.nextInt();
        
        //Calculates number of hours
        int yearsIn = years*365*24;
        int weeksIn = weeks*7*24;
        int daysIn = days*24;
        int totalHours = yearsIn + weeksIn + daysIn;
        
        //Print Result 
        System.out.println("There are " + totalHours + " hour(s) in ");
        System.out.println(years + " year(s), " + weeks + " week(s), and " + days + " day(s).");                 
        
    }
}
 
