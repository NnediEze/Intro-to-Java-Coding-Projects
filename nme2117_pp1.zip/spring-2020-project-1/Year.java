/**
*
* This class represents a calendar year. It contains 
* a method that determines if the year is a leap year.
* 
* @author: Nnedi Eze 
  nme2117
* @date: 2/10/2020
*
*/

public class Year{
    
    // declare your instance variables here
    private int year;

    // write your constructor here
    public Year(int y){
        year = y;     
    }
        
    public boolean isLeapYear(){
        if (year%400 == 0){
            return true; 
        } 
        else if (year%100 == 0){
            return false;
        }
        else if (year%4 == 0){
            return true; 
        }
        
        return false;
    }
}    