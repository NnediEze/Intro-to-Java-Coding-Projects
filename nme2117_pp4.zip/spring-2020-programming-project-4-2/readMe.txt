The Card class represents individual cards in a deck of cards. That is why each Card object has
instance variables suit and rank. The class has a compareTo method so I could compare 
individual cards in a hand, which was useful in evaluating the hand payout value. 
The accessor methods getRank() and getSuit() were also useful for evaluating hands because they made 
it easier to get the instance variables for individual cards in the Game class.

The Deck class represents the actual deck of cards. The Deck constructor uses a nested for loop to 
creates an array of 52 card objects, which contains all possible combinations of suit and rank in a 
deck of cards. The class has methods shuffle() and deal() which are actions that can be completed 
with a deck of cards in the poker game. The shuffle method shifts around all the card objects in the 
array using a random number generator and the deal method deals the top card of the deck by returning
the first card objet of the array. I added the getDeck() accessor method so I could access all 
the card objects in the deck, which was needed in the testHand Game constructor when converting 
the string objects in the stringHand Array into card objects in the theTestHand Array List.
 
The Player class represents the player playing the poker game. Each player object has instance
variables of an Array List hand, a double bet and payout, and a public String called finalHand.
The addCard() and removeCard() methods allows card objects to be removed or added to the player's 
hand. The bets() method is used by the player to place a bet, which is then subtracted from their 
bankroll. The winnings() method evaluates the total payout from the players finalhand, using the 
public variable finalHand which stores the result of the checkHand() method in the Game class. 
It multiples the betting odds * the expected payout of the finalHand. 

The Game class is where all the methods and variables used to actually play the game are located. 
I used the testHand constructor to test my checkHand methods by converting the string objects in the 
stringHand Array into card objects in the theTestHand Array List. Strings objects in the stringHand 
Array are entered in args in terminal and become the explcit parameter, testHand,
of the Game constructor, which is then stored in Stringhand. Then I ran an enhanced for loop 
to "convert" the strings in to card objects and store them in an Array List, which could then 
be evaluated by the checkHand() method. I also instantiated a deck and player object in this 
constructor, which are used to play the game. The sortHand() method sorts a players hand and the 
getHand() method returns it, which was useful in accessing values of the hand arraylist in the 
Game class. 

The other Game constructor only instantiates a deck and player object since it plays like a regular
game. The play() method is used to actually play the game. The method asks the user to enter
a token or multiple tokens in order to play the game. The tokens are added into the players bankroll
using the addToken() method in the player class. Then the bet() method in player class instructs the 
player to place a bet of at least 1 token and no more then 5 tokens. Once the bet input is made 
using p.bets() from the player class, the dealHand() method is run. This method first shuffles the 
card, and the deals the top 5 cards of the deck into the players hand. Then, the method prints 
out each card object in the hand and prompts the user if they want to hold the card or remove it, 
which is done using the removeCard() methods in the player class. Once this process 
is complete, all removed cards are replaced is complete, all removed cards are replaced and the hand
using the addCard() method from the player class and the hand is scored using the checkHand() method.

The checkHand method() is made up of helper methods wwhich evaluate all possible combinations of hands
from Royal flush to no pair. If one of the helper methods returns true, a string that represents that 
combination is the returned by the checkHand method and printed to the user. This result is stored in 
the players finalHand string and the hand payout is scored and returned using the getPayout() method 
in the player class. This payout is added to the bankroll, and the player can decide if they would 
like to play again if they still have tokens in their bankroll, or end the game. Otherwise if there
bankroll is empty, the game is over. 

