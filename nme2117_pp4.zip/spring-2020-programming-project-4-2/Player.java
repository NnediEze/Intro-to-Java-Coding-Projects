/* Nnedi Eze
 * nme2117
 * Player.java - creates player, contains players hand, keeps track of bets
 * winnings, and payout  
 */

import java.util.ArrayList;

public class Player {
	
    /****INSTANCE VARIABLES****/
		
	private ArrayList<Card> hand; //the player's cards
	private double bankroll;
    private double bet;
    private double payout;
    private String theHand;
    
    /******CONSTRUCTORS******/
    
	public Player(){
        hand = new ArrayList<Card>();
	    bankroll = 0;
        bet = 0;
	}
    
    /******METHODS*******/

	public void addCard(Card c){
	    hand.add(c); 
	}

	public void removeCard(Card c){
        hand.remove(c);
    }
		
    public void bets(double amt){
        bet = amt;
        bankroll = bankroll - bet;
        
    }

    private void winnings(double odds){
        
        if(theHand == "ROYAL FLUSH"){
            payout = odds * 250;  
        }
        
        else if(theHand == "STRAIGHT FLUSH"){
            payout = odds * 50;
        }
        
        else if(theHand == "FOUR OF A KIND"){
            payout = odds * 25;
        }
        
        else if(theHand == "FULL HOUSE"){
            payout = odds * 6;
        }
        
        else if(theHand == "FLUSH"){
            payout = odds * 5;
        }
        
        else if(theHand == "STRAIGHT"){
            payout = odds * 4;
        }
        
        else if(theHand == "THREE OF A KIND"){
            payout = odds * 3;
        }
        
        else if(theHand == "TWO PAIRS"){
            payout = odds * 2;
        }
        
        else if(theHand == "ONE PAIR"){
            payout = odds * 1;
        }
        
        else if(theHand == "NO PAIR"){
            payout = 0;
        }
            
    }

    public double getBankroll(){
        return bankroll;
    }

    public void addToken(double token){
            bankroll += token;
    }
    
    public ArrayList<Card> getHand(){
        return hand;
    }
        
    public void sortHand(ArrayList<Card> hand){
        int min;
        Card temp; 
        
        for(int i=0; i < 4; i++){
            min = i;
            for(int j=i+1; j < 5; j++){
                if(hand.get(j).compareTo(hand.get(min)) < 0){
                    min = j;
                }
            }
            
            temp = hand.get(min);
            hand.set(min, hand.get(i));
            hand.set(i,temp);
        }
    }
    
    public double getPayout(){
        this.winnings(bet);
        
        bankroll = payout + bankroll;
        
        return payout;      
    }
    
   public void setTheHand(String result){
       theHand = result;      
   }
}


