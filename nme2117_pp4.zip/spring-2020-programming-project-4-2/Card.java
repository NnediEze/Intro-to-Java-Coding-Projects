/* Nnedi Eze
 * nme2117
 * Card.java - constructs cards with suit and rank; has 
 * methods to sort and print cards
 */ 

public class Card implements Comparable<Card> {
    
    //Instance Variables 
	private int suit; //use integers 1-4 to encode the suit
	private int rank; //use integers 1-13 to encode the rank
	
    //Constructor
	public Card(int s, int r){
		suit = s;
        rank = r;
	}
	
    //Methods
    public int compareTo(Card c){
        int compare = 0;
        
        if(!(this.rank == c.rank)){           
            if(this.rank < c.rank){
                compare = -1;
            }
            
            else if(this.rank > c.rank){
                compare = 1;
            }
        }
        
        else{
            if(this.suit < c.suit){
                compare = -1;
            }
            
            else if(this.suit > c.suit){
                compare = 1;
            }
            
            else if(this.suit == c.suit){ 
                compare = 0;
            }
        }
        
        return compare;
    }
	
	public String toString(){
		String card = "";
        String stringSuit = ""; 
        
        if(suit == 1){
            stringSuit = "c";
        }
        else if(suit == 2){
            stringSuit = "d";
        }
        else if(suit == 3){
            stringSuit = "h";
        }
        else if(suit == 4){
            stringSuit = "s";
        }
        
        card = stringSuit + String.valueOf(rank);           
        
        return card; 
	}
    
	public int getSuit(){
       return suit;     
   }
   
   public int getRank(){
       return rank;  
   }
    
}
