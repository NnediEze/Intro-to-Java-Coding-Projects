/* Nnedi Eze
 * nme2117
 * Deck.java - constructs 52 card deck; 
 * methods to shuffle deck and deal cards
 */ 

import java.util.Random;
    
public class Deck {
	
    //Instance Variables 
	private Card[] cards;
	private int top; 
	
    //Constructor 
	public Deck(){
        cards = new Card[52]; 
        top = 0;
        int index = 0;          
      
        while(index < 52){
            for(int i=1; i < 5; i++){
                for(int j=1; j < 14; j++){
                    cards[index] = new Card(i,j);
                    index++; 
                }
            }
        }
    }
    
    //Methods
	public void shuffle(){
        Card temp;
        Random rand = new Random();
        int randNum;
     
		for(int i=51; i > 0; i--){
            randNum = rand.nextInt(52);
            temp = cards[randNum];
            cards[randNum] = cards[i];
            cards[i] = temp;
        }
   
       top = 0;
	}
	
	public Card deal(){
        top++;
        return cards[top-1];
        }
    
    public Card[] getDeck(){
        return cards;
    }
}