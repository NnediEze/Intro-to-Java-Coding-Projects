/* Nnedi Eze
 * nme2117
 * Game.java - constructs poker game with methods to bet, deal hand, and 
 * check hand; tells player their payout
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Game {
	
    /******INSTANCE VARIABLES******/
    
	private Player p;
	private Deck cards;
    private int countRank;
    private int bet;
    private int tokens;
    private String[] stringHand;
    private ArrayList<Card> theTestHand;
	
    /******CONSTRUCTORS******/
    
    //FOR TESTING checkHand()
	public Game(String[] testHand){
        p = new Player();
        cards = new Deck();
        theTestHand = new ArrayList<Card>();
        stringHand = testHand;
        
        for(String element : stringHand){
            for(int j=0; j < 52; j++){
                if(cards.getDeck()[j].toString().equals(element)){
                    theTestHand.add(cards.getDeck()[j]);                           
                }
            }
        }
       
        countRank = 0;
        p.sortHand(theTestHand);
        System.out.println(this.checkHand(theTestHand));     
	}
    
    //FOR PLAYING A REGULAR GAME
	public Game(){
        p = new Player();
        cards = new Deck();
	}
    
    /********METHODS********/
 
	//PLAY GAME
	public void play(){
        Scanner input = new Scanner(System.in);
        
        if(p.getBankroll() == 0 ){
            System.out.println("Welcome to Video Poker!");
            System.out.println("Please enter your token(s) to start");
        
            tokens = input.nextInt();
        
            while(tokens <= 0){
                System.out.println("Sorry, please enter a valid amount.");
            
                tokens = input.nextInt();   
            }
        
            p.addToken(tokens);
        }
        
        System.out.println("Credit : " + p.getBankroll());
        
        this.bet();
        
        this.dealHand();
        
        p.sortHand(p.getHand());
        
        p.setTheHand(this.checkHand(p.getHand()));
        
        System.out.print("Final Hand: ");
        System.out.print(p.getHand() + " --> ");
        System.out.println(this.checkHand(p.getHand()));
        
        System.out.println("Payout : " + p.getPayout());
        System.out.println("Credit : " + p.getBankroll());
        System.out.println("");
        
        if(p.getBankroll() > 0){
            System.out.println("Would you like to play again?");
            System.out.println("If so, enter yes. Enter anything else to " +
                                "end game.");
            
            String result = input.next();
            
            if("yes".equals(result)){
                System.out.println("");
                p.getHand().clear();
                this.play();
            }
            
            else{
                System.out.println("Thanks for playing! GAME OVER");       
            }           
       }
        
       else{
           System.out.println("Sorry, you are out of coins. GAME OVER");
       }        
    }
    
    //PLAYER PLACES A BET
    private void bet(){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please place a bet of no more than 5 tokens."); 
        System.out.println("You must bet at least 1 token to play.");
        
        bet = input.nextInt();
            
        while(bet > p.getBankroll() || bet > 5){
            System.out.println("Sorry, please enter a valid amount.");
            bet = input.nextInt();
        }
                
        while(bet == 0){
                System.out.println("Sorry, please enter a valid amount.");
                bet = input.nextInt();
        }
              
        p.bets(bet);      
    }
    
    //DEALS CARDS TO PLAYER, THEY KEEP/EXCHANGE CARDS
    private void dealHand(){
        cards.shuffle();
        
        for(int i=0; i < 5; i++){
            p.addCard(cards.deal());
        }
        
        System.out.print("Current Hand: ");
        System.out.println(p.getHand());
        
        int j = 0;
        int removedCards = 0;    
        Scanner input = new Scanner(System.in);
        
        for(int i=0; i < 5 ; i++){
            
            System.out.print("Do you want to keep this card? --> ");
            System.out.println(p.getHand().get(j));
            System.out.println("If so, enter yes. Enter anything else " + 
                               "to remove the card.");
                
            String result = input.next();
            
            System.out.println("");
                  
            if(!"yes".equals(result)){
                p.removeCard(p.getHand().get(j));
                
                removedCards++;
                
                System.out.print("Current Hand: ");
                System.out.println(p.getHand());               
            }
            
            else{
                System.out.print("Current Hand: ");
                System.out.println(p.getHand());  
                
                j++;
            }     
        }
        
        for(int i=0; i < removedCards; i++){
                p.addCard(cards.deal());
        }
    }
   
    //evaluates hand       
	private String checkHand(ArrayList<Card> hand){
        countRank = 0;
        
        if(this.checkRoyalFlush(hand) == true){          
            return "ROYAL FLUSH";      
        }
            
        else if(this.checkStraightFlush(hand) == true){         
            return "STRAIGHT FLUSH";    
        }
        
        else if(this.checkFourOfAKind(hand) == true){            
            return "FOUR OF A KIND";       
        }
        
        else if(this.checkFullHouse(hand) == true){
            return "FULL HOUSE";
        }
        
        else if(this.checkFlush(hand) == true){
            return "FLUSH";
        }
        
        else if(this.checkStraight(hand) == true){
            return "STRAIGHT";
        }
        
        else if(this.checkThreeOfAKind(hand) == true){
            return "THREE OF A KIND";
        }
        
        else if(this.checkTwoPairs(hand) == true){
            return "TWO PAIRS";
        }
        
        else if(this.checkOnePair(hand) == true){
            return "ONE PAIR";
        }
        
        else{
            return "NO PAIR";
        }
	}
    
    //ROYAL FLUSH
    private boolean checkRoyalFlush(ArrayList<Card> hand){
        if(this.checkStraightFlush(hand) == true && hand.get(4).getRank() == 13){
            return true;
        }
        
        return false;
    }
    
    //STRAIGHT FLUSH
    private boolean checkStraightFlush(ArrayList<Card> hand){
        if(this.checkFlush(hand) == true && this.checkStraight(hand) == true){
            return true;
        }
        
        return false;
    }
    
    //4ofaKind
    private boolean checkFourOfAKind(ArrayList<Card> hand){
        countRank = 0;
        for(int i=0; i < 4; i++){
            if(!(hand.get(i).getRank() == hand.get(i+1).getRank())){
                countRank++;
            }
        }
            
        if(countRank == 1){
            if(hand.get(0).getRank() != hand.get(1).getRank() || 
                 hand.get(3).getRank() != hand.get(4).getRank()){
                    return true;   
            }
        }
        
        return false;
    }
   
    //FULL HOUSE
    private boolean checkFullHouse(ArrayList<Card> hand){
        countRank = 0;
        for(int i=0; i < 4; i++){
            if(!(hand.get(i).getRank() == hand.get(i+1).getRank())){
            countRank++;               
            }
        }
        
       if(countRank == 1 && this.checkFourOfAKind(hand) == false){
           return true;
       }
       
       return false;         
    }
    
    //FLUSH
    private boolean checkFlush(ArrayList<Card> hand){
        for(int i=0; i < 4; i++){
            if(!(hand.get(i).getSuit() == hand.get(i+1).getSuit())){
                return false;
            }
        }
      
        return true;       
    }
    
    //STRAIGHT
    private boolean checkStraight(ArrayList<Card> hand){    
        for(int i=0; i < 4; i++){
            if(hand.get(i).getRank() == hand.get(i+1).getRank()){
                return false;
            }
        }
        
        if(hand.get(4).getRank() == hand.get(0).getRank() + 4){
            return true;
        }
        
        else if(hand.get(4).getRank() == 13){
            if(hand.get(1).getRank() + 3 == hand.get(4).getRank()){
                return true;
            }
        }
        
        return false;
    }
    
    //3ofaKind
    private boolean checkThreeOfAKind(ArrayList<Card> hand){
        countRank = 0;
        for(int i=0; i < 4; i++){
            if(hand.get(i).getRank() == hand.get(i+1).getRank()){
                countRank++;     
            }
        }

        if(countRank == 2){
            if(hand.get(2).getRank() == hand.get(4).getRank() && 
               hand.get(2).getRank() == hand.get(3).getRank()){
                return true;  
            }
            
            else if(hand.get(0).getRank() == hand.get(1).getRank() && 
                    hand.get(0).getRank() == hand.get(2).getRank()){
                return true;
            }
            
            else if(hand.get(1).getRank() == hand.get(2).getRank() && 
                    hand.get(1).getRank() == hand.get(3).getRank()){
                return true;
            }
            
            return false;          
        }
        
        return false;      
    }
    
    //TWO PAIRS
    private boolean checkTwoPairs(ArrayList<Card> hand){
        countRank = 0;
        for(int i=0; i < 4; i++){
            if(!(hand.get(i).getRank() == hand.get(i+1).getRank())){
                countRank++;     
            }
        }
        
        if(countRank == 2 && this.checkThreeOfAKind(hand) == false){
            return true;
        }
               
        return false;
    }
    
    //ONE PAIR
    private boolean checkOnePair(ArrayList<Card> hand){
        for(int i=0; i < 4; i++){
            if(hand.get(i).getRank() == hand.get(i+1).getRank()){              
                return true;
            }
        }
        
        return false;
    }
}
