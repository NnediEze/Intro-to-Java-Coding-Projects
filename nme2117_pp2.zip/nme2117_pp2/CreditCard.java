/* Nnedi Eze 
 * nme2117
 * CreditCard.java - verify Credit Card Numbers
 */

public class CreditCard
{
    //Instance Variables
    private String theCardNumber; 
    private boolean isNotValid;
    private int errorCode;
    
    //Initializes instance variables for the card to be checked; 
    //Creates CreditCard object
    public CreditCard(String creditCardNumber)
    {
        theCardNumber = creditCardNumber;
        errorCode = 0;
        isNotValid = false;
    }
     
    //Rule 1: checks if first digit is 4
    private void check1()
    {
        if(Integer.parseInt(theCardNumber.substring(0,1)) != 4)
        {
            errorCode = 1;
            isNotValid = true;
        }
    }
    
    //Rule 2: checks if 4th digit is one greater than 5th Digit
    private void check2()
    {
        if((Integer.parseInt(theCardNumber.substring(3,4)) !=
            Integer.parseInt(theCardNumber.substring(5,6)) + 1)) 
        {
            errorCode = 2;
            isNotValid = true;
        } 
    }
    
    //Rule 3: checks if product of 3rd, 5th, and 9th digit is 24 
    private void check3()
    {
        if((Integer.parseInt(theCardNumber.substring(0,1)) *
            Integer.parseInt(theCardNumber.substring(5,6)) *
            Integer.parseInt(theCardNumber.substring(10,11)) != 24))
        {
            errorCode = 3;
            isNotValid = true;
        }
    }
    
    //Rule 4: checks if sum of all digits is divisible by 4
    private void check4()
    {
        int sum = 0;
        //calculates sum
        for(int i = 0; i < theCardNumber.length(); i++)
        {
            if(!( i == 4 || i == 9))
            {
                int cardDigit = Integer.parseInt(String.valueOf(
                                theCardNumber.charAt(i)));
                
                sum += cardDigit;
            }
        }
       
        if(sum % 4 != 0) 
        {
            errorCode = 4;
            isNotValid = true;
        }           
    }
    
    //Rule 5: checks if the sum of the first 4 digits is 
    //one less than sum of the last 4 digits 
    private void check5()
    {
        int firstSum = 0;
        int lastSum = 0;
        
        //Caculates sum
        for(int i = 0; i < 4; i++)
        {
            int firstDigit = Integer.parseInt(String.valueOf
                             (theCardNumber.charAt(i)));
           
            firstSum += firstDigit;
        }

        for(int j = 10; j < 14; j++)
        {
            int lastDigit = Integer.parseInt(String.valueOf(
                            theCardNumber.charAt(j)));
               
            lastSum += lastDigit;
        }
        
        if(firstSum != lastSum - 1)
        {
            errorCode = 5;
            isNotValid = true;
        }       
    }
    
    //Rule 6: checks if the sum of the first 2 digits 
    //as a two-digit number and the seventh and eight 
    //digits as a two digit number is 100
    private void check6()
    {
        //Caculates sum
        int firstSum = Integer.parseInt(theCardNumber.substring(0,2)); 
        int lastSum = Integer.parseInt(theCardNumber.substring(7,9));
        
        if (firstSum + lastSum != 100) 
        {
           errorCode = 6;
           isNotValid = true;
        }
        
    }
         
    //Runs all checks to validate credit card #
    public void check()
    {
        this.check1();
        
        if(!isNotValid)
        {
            this.check2();
            
            if(!isNotValid)
            {
                this.check3();
                
                if(!isNotValid)
                {
                  this.check4(); 
                  
                  if(!isNotValid)
                  {
                      this.check5();
                      
                      if(!isNotValid)
                      {
                         this.check6(); 
                      }
                  }
               }
            }
        }
    }
  
    //Tells if credit card number is valid or not
    public boolean isValid()
    {
        return !(isNotValid);    
    }
    
    //Tells value of errorCode
    public int getErrorCode()
    {
        return errorCode;
    }
}