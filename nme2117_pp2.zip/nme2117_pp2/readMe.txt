The CreditCard.java program validates a credit card number by 
assigning new card numbers to the CreditCard class, which has instance 
variables theCardNumber, isNotValid, and errorCode. 

When a new credit card number is input, its value is stored as a string in the variable creditCardNumber. 
The constructor assigns the credit card to the object card and runs the main method 
CreditCard(), which assigns the variable thecardNumber to the value of the creditCardNumber, the boolean
isNotValid to false, and variable errorCode to zero. isNotValid is used to determine if the credit card number 
passes the checks is runs through the check method and the errorcode is used to determine if 
which check the credit card number fails if any. 

The method check contains the rules that the credit card needs to follow to be validated. This method is 
made up of if and else if statements. It is based on the fact that the creditCardNumber is assumed to be valid (isNotValid
= false) and must follow all the rules in order to remain valid. Every else if statement for each check 
has the condition !(isNotValid), meaning isNotValid must have the value of false or have not failed the 
previous check to continue to the next check.

I used for loops for rules 4 5, and 6 that required the sum of digits in the account number and placed them outside of the 
if and else if statements for clarity. 



