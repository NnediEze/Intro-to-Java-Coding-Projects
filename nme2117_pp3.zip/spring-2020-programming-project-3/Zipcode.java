/*****************************************
 * nme2117
 * @author Nnedi Eze
 * Zipcode.java - A template for a Nim game
 ****************************************/

import java.util.Scanner; 

public class Zipcode{
    
    //instance variables
    private String zip;
    private String bar;
    private String barcode;
    private String zipcode;
    private String checkDigit;
    
    //methods   
    //zipcode to barcode
    public Zipcode(int zipcode){
        
        zip = String.valueOf(zipcode);
        barcode = "|";
        this.checkZIP();
        this.convertToBar();
    }
    
    //checks for leading 0s in zipcode
    private void checkZIP(){
        
        if(zip.length() == 4){
        
        zip = "0" + zip;
        
        }
        
        else if(zip.length() == 3){
        
        zip = "00" + zip;
        
        }
        
        else if(zip.length() == 2){
        
        zip = "000" + zip;
        
        }
        
        else if(zip.length() == 1){
        
        zip = "0000" + zip;
    
        }
        
        else if(zip.length() == 0){
        
        zip = "00000";
        }
    }
        
    private void convertToBar(){
        
        for(int i=0; i < zip.length(); i++){
        
            if(zip.charAt(i) == '0'){
            
                barcode += "||:::";
            }
            
            else if(zip.charAt(i) == '1'){
            
                barcode += ":::||";
            }
        
            else if(zip.charAt(i) == '2'){
            
                barcode += "::|:|";       
            }
        
            else if(zip.charAt(i) == '3'){
            
                barcode += "::||:";
            }
            
            else if(zip.charAt(i) == '4'){
            
                barcode += ":|::|";
            }
        
            else if(zip.charAt(i) == '5'){
            
                barcode += ":|:|:";
            }
        
            else if(zip.charAt(i) == '6'){
            
                barcode += ":||::";
            }
            
            else if(zip.charAt(i) == '7'){
            
                barcode += "|:::|";
            }
            
            else if(zip.charAt(i) == '8'){
            
                barcode += "|::|:";
            }
            
            else if(zip.charAt(i) == '9'){
            
                barcode += "|:|::";
            }    
        }
        
        this.getCheckDigit();
        barcode = barcode + checkDigit + "|";      
    }
    
    //check digit calculation 
    private void getCheckDigit(){
        int sum = 0;
        int digit = 0;
        
        for(int i =0; i < zip.length(); i++){
            
            sum += Integer.parseInt(String.valueOf(zip.charAt(i)));
        }
        
        String stringSum = String.valueOf(sum);
        
        if(sum != 10){
        digit = 10 - Integer.parseInt(String.valueOf(stringSum.charAt(
                                                         stringSum.length()-1)));
        }
      
        if(digit == 0){
            checkDigit = "||:::";
        }
    
        else if(digit == 1){
            checkDigit = ":::||";
        }
        
        else if(digit == 2){
            checkDigit = "::|:|";       
        }
        
        else if(digit == 3){
            checkDigit = "::||:";
        }
            
        else if(digit == 4){          
            checkDigit = ":|::|";
        }
        
        else if(digit == 5){
            checkDigit = ":|:|:";
        }
        
        else if(digit == 6){ 
            checkDigit = ":||::";
        }
            
        else if(digit == 7){  
            checkDigit = "|:::|";
        }
            
        else if(digit == 8){
            checkDigit = "|::|:";
        }
            
        else if(digit == 9){
            checkDigit = "|:|::";
        }        
    }

    // barcode to zipcode 
    public Zipcode(String barcode){
        bar = barcode;
        zipcode = "";
        this.convertToZIP();
    }
    
    private void convertToZIP(){
    
        for(int i=1; i < 22 ; i = i+5){
        
            String bars = bar.substring(i, i+5);
        
            if (bars.equals("||:::")){
            
                zipcode += "0";   
            }
        
            else if(bars.equals(":::||")){
            
                zipcode += "1";
            }
        
            else if(bars.equals("::|:|")){
            
                zipcode += "2";
            }
        
            else if(bars.equals("::||:")){
            
                zipcode += "3";
            }
        
            else if(bars.equals(":|::|")){
            
                zipcode += "4";
            }
        
            else if(bars.equals(":|:|:")){
            
                zipcode += "5";
            }
        
            else if(bars.equals(":||::")){
            
                zipcode += "6";         
            }
        
            else if(bars.equals("|:::|")){
            
                zipcode += "7";           
            }
        
            else if(bars.equals("|::|:")){
            
                zipcode += "8";
            }
        
            else if(bars.equals("|:|::")){
            
                zipcode += "9";
            }
        }
    }
    
    public String getBarcode(){
        if(barcode.length() != 32){
            return "error in barcode";
        }
       
        else{
            return barcode; 
        }
    }

    public String getZIPcode(){
        if(zipcode.length() != 5){
            return "error in zipcode";
        }
        
        else{
            return zipcode;
        }
    }  
}