/*****************************************
 * nme2117
 * @author Nnedi Eze
 * Nim.java - Test class for Nim game 
 ****************************************/ 

import java.util.Scanner;

public class Nim{
    public static void main(String[] args){
        
        System.out.println("Welcome to Nim death match!");
        
        Scanner input = new Scanner(System.in);
        System.out.println("What difficulty level do you want to playt 1/2?");
        int level = input.nextInt();
        Game g = new Game(level);
        g.play();

        System.out.println("Let's determine the level randomly, now.");
        
        Game g2 = new Game();
        g2.play();

        System.out.println("Thanks for playing!");
    }
}