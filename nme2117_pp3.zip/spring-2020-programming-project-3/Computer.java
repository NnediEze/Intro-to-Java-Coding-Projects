/*****************************************
 * nme2117
 * @author Nnedi Eze
 * Computer.java - A template for a computer Nim player
 ****************************************/ 
import java.util.Random; 
    
public class Computer{
    private int mode;
    private int choice;
    
    public Computer(int m){
       
        // use this constructor for the Computer 
        mode = m;
        choice = -1;
    }
    
    public void move(int marblesLeft){
        Random generator = new Random();
        //smart mode if mode = 2
        if(mode == 2){
            
            if(marblesLeft == 63){
                
                choice = 1 + generator.nextInt(marblesLeft/2);  
            }
            else if(62 < marblesLeft){
            
                choice = marblesLeft - 63;
            } 
            
            else if(marblesLeft == 31) {
                
                 choice = 1 + generator.nextInt(marblesLeft/2);
            }
            else if(30 < marblesLeft){
            
                choice = marblesLeft - 31;
            } 
            
            else if(marblesLeft == 15) {
                choice = 1 + generator.nextInt(marblesLeft/2);
            }
            else if(14 < marblesLeft){
            
                choice = marblesLeft - 15; 
            } 
            
            else if(marblesLeft == 7){
                
                choice = 1 + generator.nextInt(marblesLeft/2);
            }
            else if(6 < marblesLeft){
            
                choice = marblesLeft - 7;
            }
            
            else if(marblesLeft == 3){
                
                choice = 1 + generator.nextInt(marblesLeft/2);
            }
            else if(2 < marblesLeft){
                
                choice = marblesLeft - 3;
            }
            
            else if(marblesLeft == 1){
                
                choice = 1 + generator.nextInt(marblesLeft/2);
            }
            else if(0 < marblesLeft){
                
                choice = marblesLeft - 1;
            }       
        }
    
    //stupid mode if mode = 1
        else{
            
            generator = new Random();
            choice = 1 + generator.nextInt(marblesLeft/2);
        }         
    }
   
    public int getChoice(){
        
        return choice;
    }    
}
