/*****************************************
 * nme2117
 * @author Nnedi Eze
 * Game.java - A template for a Nim game
 ****************************************/ 
import java.util.Random; 

public class Game{
    
    private int marbles;
    private Human humanPlayer;
    private Computer computerPlayer;
    private Random generator;
    private int difficulty;
    private int firstTurn;
    
    //determine the level automatically
    public Game(){
        generator = new Random();
        difficulty =  1 + generator.nextInt(2);
        marbles = 10 + generator.nextInt(91);
        
        //Create players 
        computerPlayer = new Computer(difficulty);
        humanPlayer = new Human(); 
           
        firstTurn = generator.nextInt(1);     
    }
    
    //specify the level of game play
    public Game(int level){
        generator = new Random();
        difficulty = level;
        marbles = 10 + generator.nextInt(91);
        
        //Create players
        computerPlayer = new Computer(level);
        humanPlayer = new Human();
        
        firstTurn = generator.nextInt(1); 
    }
    
    //moves for the computer
    private void playComputer(){
        computerPlayer.move(marbles);
                    
        this.updateMarblesComputer();
                    
        System.out.println("The computer took " + 
            computerPlayer.getChoice() + " marbles. There are " 
            + marbles + " left.");          
    }
    
    //moves for human
    private void playHuman(){       
        humanPlayer.move();
            
        if(humanPlayer.getChoice() < 1 || humanPlayer.getChoice() 
           > (marbles/2)){
                
            System.out.println("Please try again.");
                
            playHuman();       
        }
        
        else{
            updateMarblesHuman();
            
            System.out.println("You took " + humanPlayer.getChoice() + 
                               " marbles. There are " + marbles + " left.");
        }
    }
   
    public void play(){
        System.out.println("You are playing level " + difficulty + " .");
        System.out.println("The pile has " + marbles + " marbles.");
        
        while(marbles > 0){
            
            //if computer has first turn           
            if(firstTurn == 0){
                System.out.println("The computer has the first turn.");
            
                this.playComputer();
                
                if(marbles == 1){
                    System.out.println("Sorry! You lose : computer wins");
                    
                    break;
                }
            
                this.playHuman();
            
                if(marbles == 1){
                    System.out.println("Yay! You win : computer loses");
                    
                    break;
                }
           }
           
           //human has first turn
           else{
 
               System.out.println("You have the first turn.");
           
               playHuman();
           
               if(marbles == 1){
                   System.out.println("Yay! You win : computer loses");
                
                    break;
               }
           
               playComputer();
           
               if(marbles == 1){
                   System.out.println("Sorry! You lose : compuser wins");
                
                   break;
               }
            }        
        }
    }
               
    // you may wish to add more methods here
    private void updateMarblesComputer(){
        
        marbles = marbles - computerPlayer.getChoice();
    }
    
    private void updateMarblesHuman(){
        
        marbles = marbles - humanPlayer.getChoice();
    }
}