/*****************************************
 * nme2117
 * @author Nnedi Eze
 * Human.java - A template for a Human Nim player
 ****************************************/ 
import java.util.Scanner;

public class Human{
   
    private int choice;
    private Scanner input;
   
    public Human(){
        
        // use this constructor for the Human
        input = new Scanner(System.in);
        choice = -1;
    }
    
    public void move(){
            
        choice = input.nextInt();
    }
    
    public int getChoice(){
        
        return choice;
    }  
}
