THE GAME OF NIM

The Nim class creates a new game by instanitiating a new object of the game class. 
The Game constructor is overloaded to the player can choose the level of difficulty of the game.

First, the player is allowed to choose their level of game play when the game object g is instantiated and 
this value is printed out. The other Game constructor can choose the level automatically by using a random number 
generator that generates numbers 1 and 2 only. Both randomly generate the number of marbles and prints out this value 
as well as instantiating objects of the Computer and Player classes that represent the players. 

Then the method play() is invoked on the game object. The play method first decides which player is going first 
through generating a random number 0 or 1. If 0 is generated, the computer has the first turn and the playComputer() method is run. Otherwise, 
the human goes first and the playHuman() method runs. It runs a while loop while the number of marbles in the pile is greater than zero and begins the game.

The move() method  by the computer is determined  the game level. If the game level is 1 which corresponds to easy mode,
the computer generates a random number between 1 to the total number of marbles divided by 2 inclusive and takes it from the pile. If the game 
level is 2, the computer plays smart and leaves off enough marbles to make the size of the pile a power of two minus. 
This is verified by multiple if and else statements. If the number of marbles in the pile equals 3, 7, 15, 31, or 63, the computer 
behaves as if it was in easy mode and takes a random amount. The change in the total amount of marbles is updated in the game class 
through the updateMarblesComputer() method.

The Human move() method takes inputs from the human player on how much it should be taken from the pile.
The change in the total amount of marbles is updated in the game class through the updateMarblesHuman() method.

ZIPTEST

The Zipcode constructor is overloaded so it can convert Zipcodes to barcodes and barcodes to Zipcodes. 
To change a zipcode to a barcode, a zipcode is entered into the constructor and becomes a new instance
of zipcode class. The method getbarcode() is then invoked on this object, whice first checks for leading
zeroes in the barcode and add them back to the zipString because the the zip int removes them, and then runs the method convertToBar().
The convertToBar method is a for loop of several if and else if statements that runs through each character in the zipcode object 
and adds its barcode equivalent to the instance variable barcode to produce the coverred result. 

Then the method checkdigit() is run, to get the check digit at the end. The check digit runs a for loop to 
to add all the digits of the zipcode object into variable total. Then subtracts this total from 20 and stores it 
in the Checkdigit string, which is then put through if and else if statements to find its barcode equivalent and add it 
to the final barcode at the end. Once this is calculated, the program returns the barcode back to the tester. 

Next, a barcode is converted to a zipcode using the same process. The zipcode constructor makes a barcode object, the getZIP method verifies 
that the length of the barcode object is a valid 32 characters, and then the convertoZip method is run as a for loop 
which checks every 5 characters, find which digit the characters represent, and then adds them to the variable Zipcode, which is returned to the tester