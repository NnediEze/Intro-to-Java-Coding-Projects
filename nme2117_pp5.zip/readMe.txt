In Talk.java, I wrote a constructor for the Talk class, where each instance of this class can 
be considered a talk that needs to be scheduled. The instance variables are the speaker, the 
startTime, and the endTime of the talk. Methods in talk class are the compareTo(), toString(), and 
accessor methods getStartTime() and getEndTime(). The compareTo() method sorts by the start time and
then by the endTime, taking into consideration the string format of the Time and making sure it is 
correctly converted into an Int equivalent. I threw a NumberFormatException to catch if the times being 
sorted had an invalid format as well. The to String() method helps to print Talk objects as strings. 
It returns a String called talk which is equal to the instance variables of talk added together and 
printed on a single line. The getStartTime() and getEndTime() methods are simply an acesssor methods
in order to access the start and end times of a talk from the Scheduler class.

In the Scheduler class, I first established an input stream to get the information from the file 
to the String arraylist called list. Then a new arraylist of Talk objects was initialized and 
filled using the Talk constructor, which pulled on different indices of the list array to make sure
the right values were stored in the correct instance variables. Then, I sorted the ArrayList talks
using the SortTalks () method and returned talks. The next method Scheduletalks is an implementation
of the algorithm I chose to fit the most talks in a room. I made a new array list schedule that would
be the final schedule, a boolean addTalk, an int scheduleIndex to keep track of the index of the 
schedule ArrayList, and a counter to keep track of the value of i or the elements of array list 
talks that I had added to the schedule. I ran a for loop within a while 
loop, so that while the last element of the talks array had not been added to the schedule, I would 
look through the array list and see which value of the startTime value on a talk in the talks 
array list was eqcal to the value of endTime of the last talk added to the schedule. If no talk 
met this requirement, meaning the boolean would remain false, I would increase the endTime of the
last talk by 5 mins increments and recheck until the next closest talk was found, and then restart
the process. At the end, I would return the final schedule. I added another exception to check 
for if the text file specified at the command line is empty, which means that all the indices for
the array lists are out of bounds, because they have a values of zero. 