/* Nnedi Eze 
 * nme2117
 * Scheduler.java - 
 */
// This is your Scheduler class
// This class should store static methods

import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;

public class Scheduler
{
    
    // this static method should take in a file name and return an ArrayList of Talk objects
    // notice that it might throw an IOException
    public static ArrayList<Talk> makeTalks(String fileName) throws IOException
    {  
        ArrayList<String> list = new ArrayList<String>();
        ArrayList<Talk> talks = new ArrayList<Talk>();
        File inFile = new File(fileName); 
        Scanner input = new Scanner(inFile);
        
        try
        {          
            while(input.hasNext())
            {
                list.add(input.next());            
            }
                     
            input.close();
            
            for(int i=0; i < list.size() - 2; i=i+3)
            {
                talks.add(new Talk(list.get(i), list.get(i+1), list.get(i+2)));
            }  
                       
            Scheduler.sortTalks(talks);
        
        }
        
        catch(NumberFormatException ex)
        {
            System.out.println(ex + " talk has an invalid time.");
        }
             
        return talks;
    }
    
    // this static method should take in an ArrayList of Talk objects and return a maximum 
    // size subset of those talks that may be scheduled together in a single room.
    public static ArrayList<Talk> scheduleTalks(ArrayList<Talk> talks)
    {
        ArrayList<Talk> schedule = new ArrayList<Talk>();
        int counter = 0;
        int scheduleIndex = 0;
        boolean addTalk = false;
        
        try{          
            schedule.add(talks.get(0));
        
            if(!(talks.size() > 0))
            {
                throw new IndexOutOfBoundsException("invalid");
            }
        
            String nextTalk = schedule.get(scheduleIndex).getEndTime();
        
            for(int j=0; j < 100; j++)
            {          
                if(counter != talks.size()-1)
                {    
                    for(int i=counter+1; i < talks.size(); i++)
                    {
                        if(talks.get(i).getStartTime().equals(nextTalk))
                        {
                            addTalk = true;
                            schedule.add(talks.get(i));
                            counter = i;
                            scheduleIndex++;
                            nextTalk = schedule.get(scheduleIndex).getEndTime();                                                  
                        } 
                        
                        else
                        {
                            addTalk = false;
                        }
                    }
                 
                    if(addTalk == false)
                    {
                        if(nextTalk.substring(0,1).equals("0") && 
                           !(nextTalk.equals("0955")))
                        {
                            nextTalk = nextTalk.substring (0,1) + 
                            String.valueOf(Integer.parseInt(
                            nextTalk.substring(1,4)) + 5);
                        }
                        
                        else if(nextTalk.equals("0955"))
                        {
                            nextTalk = "1000";
                        }
                        
                        else
                        {
                           nextTalk = String.valueOf(
                           Integer.parseInt(nextTalk) + 5);
                        }
                    }
                }
            }
        }
        
        catch(IndexOutOfBoundsException e)
        {
            System.out.println("No text found, File specified is empty");
        }
        
        return schedule;
 
    }
    
    // you may or may not want to add more methods here
    public static void sortTalks(ArrayList<Talk> talks)
    {
        int min;
        Talk temp;
        
        for(int i=0; i < talks.size()-1; i++)
        {
            min = i;
            for(int j=i+1; j < talks.size(); j++)
            {
                if(talks.get(j).compareTo(talks.get(min)) < 0)
                {
                    min = j;
                }
            }
            
            temp = talks.get(min);
            talks.set(min, talks.get(i));
            talks.set(i, temp);
        }
    }
    
}