/* Nnedi Eze
 * nme2117
 * Talk.java - 
 */

public class Talk implements Comparable<Talk>
{
    
    /*****INSTANCE VARIABLES****/
    private String speaker;
    private String startTime;
    private String endTime;
    
    /****METHODS****/
    public Talk(String name, String start, String end)
    {
        speaker = name;
        startTime = start;
        endTime = end;
    }
    
    public int compareTo(Talk t) throws NumberFormatException
    {
        int compare = 0;
        
        if(Integer.parseInt(this.startTime.substring(0,1)) > 2 || 
           this.startTime.substring(0,2).equals("00"))
        {
           throw new NumberFormatException(this.speaker);
        }

        else if(Integer.parseInt(t.endTime.substring(0,1)) > 2 || 
                t.endTime.substring(0,2).equals("00"))
        {
           throw new NumberFormatException(t.speaker);   
        }
            
        else
        {
            if(this.startTime.substring(0,1).equals("0") && 
               t.startTime.substring(0,1).equals("0"))
            {
                if(Integer.parseInt(this.startTime.substring(0,4)) < 
                   Integer.parseInt(t.startTime.substring(0,4)))
                {
                    compare = -1;
                }
                
                else if(Integer.parseInt(this.startTime.substring(0,4)) > 
                        Integer.parseInt(t.startTime.substring(0,4)))
                {
                    compare = 1;
                }
                
                else
                {
                    if(Integer.parseInt(this.endTime.substring(0,4)) < 
                       Integer.parseInt(t.endTime.substring(0,4)))
                    {
                        compare = -1;
                    }
                   
                    else if(Integer.parseInt(this.endTime.substring(0,4)) > 
                           Integer.parseInt(t.endTime.substring(0,4)))
                    {
                        compare = 1;
                    }
                   
                    else
                    {
                        compare = 0;
                    }
                }
            }
               
            else if(this.endTime.substring(0,1).equals("0"))
            {
                if(Integer.parseInt(this.startTime.substring(0,4)) < 
                   Integer.parseInt(t.startTime))
                {
                    compare = -1;
                }
                
                else if(Integer.parseInt(this.startTime.substring(0,4)) > 
                        Integer.parseInt(t.startTime))
                {
                    compare = 1;
                }
                
                else
                {
                    if(Integer.parseInt(this.endTime.substring(0,4)) < 
                       Integer.parseInt(t.endTime))
                    {
                        compare = -1;
                    }
                    
                    else if(Integer.parseInt(this.endTime.substring(0,4)) >
                            Integer.parseInt(t.endTime))
                    {
                        compare = 1;
                    }
                    
                    else
                    {
                        compare = 0;                    
                    }                                     
                }        
            }
            
            else if(t.endTime.substring(0,1).equals("0"))
            {
                if(Integer.parseInt(this.startTime) < 
                   Integer.parseInt(t.startTime.substring(0,4)))
                {
                    compare = -1;
                }
                
               else if(Integer.parseInt(this.startTime) > 
                       Integer.parseInt(t.startTime.substring(0,4)))
               {
                   compare = 1;
               }
               
               else
               {
                   if(Integer.parseInt(this.endTime) < 
                      Integer.parseInt(t.endTime.substring(0,4)))
                   {
                       compare = -1;
                   }
                   
                   else if(Integer.parseInt(this.endTime) > 
                           Integer.parseInt(t.endTime.substring(0,4)))
                   {
                       compare = 1;
                   }
                   
                   else
                   {
                       compare = 0;
                   }
               }
            }
            
            else
            {
                if(Integer.parseInt(this.startTime) < 
                   Integer.parseInt(t.startTime))
                {
                    compare = -1;
                }
                
                else if(Integer.parseInt(this.startTime) > 
                        Integer.parseInt(t.startTime))
                {
                    compare = 1;
                }
                
                else
                {
                    if(Integer.parseInt(this.endTime) < 
                       Integer.parseInt(t.endTime))
                    {
                        compare = -1;
                    }
                    
                    else if(Integer.parseInt(this.endTime) >
                            Integer.parseInt(t.endTime))
                    {
                        compare = 1;
                    }
                    
                    else
                    {
                        compare = 0;
                    }
                    
                }      
            }
        }
        
        return compare;     
    }
    
    public String toString()
    {
        String talk;
        
        talk = speaker + "  " + startTime + " " + endTime;
        
        return talk;
    }
    
    public String getStartTime()
    {
        return startTime;
    }
    
    public String getEndTime()
    {
        return endTime;
    }   
}
